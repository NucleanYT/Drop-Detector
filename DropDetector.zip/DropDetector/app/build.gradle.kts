plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Every GitHub build gets a higher number, so the app can tell when a newer one exists.
val buildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.broski.dropdetector"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.broski.dropdetector"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.$buildNumber"
    }

    // Same signing key on every build, so new versions install over old ones.
    signingConfigs {
        create("fixed") {
            storeFile = file("drop.keystore")
            storePassword = "broski123"
            keyAlias = "drop"
            keyPassword = "broski123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
