package com.broski.dropdetector

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.min
import kotlin.math.sqrt

class DropService : Service(), SensorEventListener {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.broski.dropdetector.STOP"
        private const val CHANNEL = "armed"

        // Tuning: free fall reads close to 0 g. Same values as the web version.
        private const val FALL_MS = 120L          // ...for at least this long
        private const val COOLDOWN_MS = 3000L
    }

    private lateinit var sensors: SensorManager
    private var listening = false
    private var fallStart = -1L
    private var lastTrigger = 0L

    // After a drop triggers, keep timing the fall until the phone lands.
    private var measuringFrom = -1L
    private var measuringWall = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        DropOverlay.loadThreshold(this)
        goForeground()
        if (!listening) {
            sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
                listening = true
            }
        }
        running = true
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Drop detector armed", NotificationManager.IMPORTANCE_LOW)
        )

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, DropService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Drop detector is armed")
            .setContentText("Don't drop me, broski")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .setContentIntent(openApp)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Disarm", stop
                ).build()
            )
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
        val now = SystemClock.elapsedRealtime()

        // Landing: force comes back above the trigger line (or give up after 3 s).
        if (measuringFrom >= 0 && (g >= DropOverlay.thresholdG || now - measuringFrom > 3000)) {
            DropOverlay.recordFall(this, measuringWall, min(now - measuringFrom, 3000L))
            measuringFrom = -1L
        }

        if (g < DropOverlay.thresholdG) {
            if (fallStart < 0) fallStart = now
            if (now - fallStart >= FALL_MS && now - lastTrigger > COOLDOWN_MS) {
                lastTrigger = now
                measuringFrom = fallStart
                measuringWall = System.currentTimeMillis() - (now - fallStart)
                fallStart = -1L
                DropOverlay.show(this, realDrop = true)
            }
        } else {
            fallStart = -1L
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        sensors.unregisterListener(this)
        listening = false
        running = false
        super.onDestroy()
    }
}
