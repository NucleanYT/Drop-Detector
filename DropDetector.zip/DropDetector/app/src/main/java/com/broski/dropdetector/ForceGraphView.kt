package com.broski.dropdetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Scrolling line graph of the last few seconds of force on the phone. */
class ForceGraphView(ctx: Context, private val look: Look) : View(ctx) {

    private val cap = 250
    private val data = FloatArray(cap)
    private var n = 0
    private var head = 0
    private val d = ctx.resources.displayMetrics.density
    private val maxG = 2f

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        color = look.onCard
    }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.5f * d
        strokeCap = Paint.Cap.ROUND
        color = look.accent
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(22, Color.red(look.onCard), Color.green(look.onCard), Color.blue(look.onCard))
    }
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * d
        color = look.line
    }
    private val trigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = look.accent
        pathEffect = DashPathEffect(floatArrayOf(6f * d, 5f * d), 0f)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = look.muted
        textSize = 11f * d
    }
    private val trigLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = look.accent
        textSize = 11f * d
        isFakeBoldText = true
    }
    private val path = Path()
    private val fill = Path()
    private val dash = Path()

    fun push(g: Float) {
        data[head] = g
        head = (head + 1) % cap
        if (n < cap) n++
        invalidate()
    }

    private fun yFor(g: Float, top: Float, h: Float) =
        top + (1f - min(max(g, 0f), maxG) / maxG) * h

    private fun sample(i: Int) = data[(head - n + i + cap * 2) % cap]

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val top = 6f * d
        val h = height - 12f * d
        if (w <= 0f || h <= 0f) return

        // 1 g resting line
        val yBase = yFor(1f, top, h)
        c.drawLine(0f, yBase, w, yBase, basePaint)
        c.drawText("1 g resting", 2f * d, yBase - 5f * d, labelPaint)

        // Trigger line (from the sensitivity slider)
        val thr = DropOverlay.thresholdG
        val yT = yFor(thr, top, h)
        dash.reset()
        dash.moveTo(0f, yT)
        dash.lineTo(w, yT)
        c.drawPath(dash, trigPaint)
        val tl = "trigger"
        c.drawText(tl, w - trigLabelPaint.measureText(tl) - 2f * d, yT - 5f * d, trigLabelPaint)

        if (n < 2) return
        val step = w / (cap - 1)

        path.reset()
        fill.reset()
        for (i in 0 until n) {
            val x = w - (n - 1 - i) * step
            val y = yFor(sample(i), top, h)
            if (i == 0) {
                path.moveTo(x, y)
                fill.moveTo(x, top + h)
                fill.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(w, top + h)
        fill.close()
        c.drawPath(fill, fillPaint)
        c.drawPath(path, linePaint)

        // Paint the parts that dipped below the trigger line red
        var px = 0f
        var py = 0f
        var prevHot = false
        for (i in 0 until n) {
            val g = sample(i)
            val x = w - (n - 1 - i) * step
            val y = yFor(g, top, h)
            val hot = g < thr
            if (i > 0 && hot && prevHot) c.drawLine(px, py, x, y, hotPaint)
            px = x
            py = y
            prevHot = hot
        }
    }
}
