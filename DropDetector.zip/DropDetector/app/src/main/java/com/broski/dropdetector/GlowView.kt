package com.broski.dropdetector

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** A soft blurred glow drawn behind a button. */
class GlowView(
    ctx: Context,
    glowColor: Int,
    private val cornerPx: Float,
    private val blurPx: Float,
) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = glowColor
        maskFilter = BlurMaskFilter(blurPx, BlurMaskFilter.Blur.NORMAL)
    }
    private val rect = RectF()

    init {
        // Blur only renders in software.
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setGlowColor(c: Int) {
        paint.color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        rect.set(blurPx, blurPx, width - blurPx, height - blurPx)
        if (rect.width() > 0f && rect.height() > 0f) {
            canvas.drawRoundRect(rect, cornerPx, cornerPx, paint)
        }
    }
}
