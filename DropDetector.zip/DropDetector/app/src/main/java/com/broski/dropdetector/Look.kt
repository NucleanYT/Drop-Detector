package com.broski.dropdetector

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable

/** The app's color and shape styles. Index 0 is the original look. */
class Look(
    val name: String,
    val bg: Int,            // page background
    val onBg: Int,          // text on the page background
    val mutedOnBg: Int,     // quiet text on the page background
    val edgeOnBg: Int,      // outline of buttons sitting on the background
    val card: Int,          // card background
    val onCard: Int,        // main text in cards
    val muted: Int,         // quiet text in cards
    val soft: Int,          // small labels in cards
    val hint: Int,          // empty text-box hint
    val line: Int,          // outlines and tracks inside cards
    val accent: Int,        // selected pills, sliders, switches
    val onAccent: Int,      // text on accent
    val accentOnBg: Int,    // accent-colored text on the page background
    val armed: Int,         // arm button fill while armed
    val onArmed: Int,       // text on the armed button
    val armedHint: Int,
    val ringColor: Int,     // pulsing ring while armed
    val thumbOff: Int,      // switch thumb when off
    val ripple: Int,
    val cardRadius: Int,    // dp
    val pillRadius: Int,    // dp
    val headFace: Typeface,
    val shoutyHeadline: Boolean,
    val stripes: Boolean,   // caution-tape band at the top
    val lightBars: Boolean, // dark status-bar icons
    val dialogTheme: Int,
) {
    companion object {
        private fun c(hex: String) = Color.parseColor(hex)

        val ALL = listOf(
            Look(
                name = "Classic",
                bg = c("#0E0E11"), onBg = Color.WHITE, mutedOnBg = c("#8E8E96"), edgeOnBg = c("#2C2C33"),
                card = c("#1A1A1F"), onCard = Color.WHITE, muted = c("#8E8E96"), soft = c("#C8C8CE"),
                hint = c("#55555C"), line = c("#2C2C33"),
                accent = c("#FF4A32"), onAccent = Color.WHITE, accentOnBg = c("#FF4A32"),
                armed = c("#FF4A32"), onArmed = Color.WHITE, armedHint = c("#FFD9D3"), ringColor = c("#FF4A32"),
                thumbOff = c("#B0B0B6"), ripple = c("#33FFFFFF"),
                cardRadius = 20, pillRadius = 18,
                headFace = Typeface.DEFAULT_BOLD, shoutyHeadline = false,
                stripes = false, lightBars = false,
                dialogTheme = android.R.style.Theme_DeviceDefault_Dialog_Alert,
            ),
            Look(
                name = "Hazard",
                bg = c("#FFD60A"), onBg = c("#111111"), mutedOnBg = c("#5A4A00"), edgeOnBg = c("#111111"),
                card = c("#111111"), onCard = Color.WHITE, muted = c("#FFD60A"), soft = c("#D6D6D6"),
                hint = c("#6B6B6B"), line = c("#3A3A3A"),
                accent = c("#FFD60A"), onAccent = c("#111111"), accentOnBg = c("#111111"),
                armed = c("#E5231B"), onArmed = Color.WHITE, armedHint = c("#FFD0CC"), ringColor = c("#111111"),
                thumbOff = c("#8A8A8A"), ripple = c("#40808080"),
                cardRadius = 6, pillRadius = 4,
                headFace = Typeface.create("sans-serif-condensed", Typeface.BOLD), shoutyHeadline = true,
                stripes = true, lightBars = true,
                dialogTheme = android.R.style.Theme_DeviceDefault_Light_Dialog_Alert,
            ),
        )

        private const val KEY = "look"

        fun index(ctx: Context) =
            ctx.applicationContext.getSharedPreferences("drop", Context.MODE_PRIVATE)
                .getInt(KEY, 0).coerceIn(0, ALL.size - 1)

        fun save(ctx: Context, i: Int) =
            ctx.applicationContext.getSharedPreferences("drop", Context.MODE_PRIVATE)
                .edit().putInt(KEY, i).apply()

        fun current(ctx: Context) = ALL[index(ctx)]
    }
}

/** Diagonal black-and-yellow caution-tape stripes. */
class StripesDrawable(private val a: Int, private val b: Int, private val stripePx: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val r = bounds
        paint.color = a
        canvas.drawRect(r, paint)
        paint.color = b
        val h = r.height().toFloat()
        var x = r.left - h
        while (x < r.right + h) {
            path.reset()
            path.moveTo(x, r.bottom.toFloat())
            path.lineTo(x + stripePx, r.bottom.toFloat())
            path.lineTo(x + stripePx + h, r.top.toFloat())
            path.lineTo(x + h, r.top.toFloat())
            path.close()
            canvas.drawPath(path, paint)
            x += stripePx * 2
        }
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.OPAQUE
}
