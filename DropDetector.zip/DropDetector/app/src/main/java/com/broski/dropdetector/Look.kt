package com.broski.dropdetector

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface

/** The app's color and shape styles. "Classic" is the original look. */
class Look(
    val website: Boolean,   // use the website-style layout
    val bg: Int,            // page background
    val onBg: Int,          // text on the page background
    val mutedOnBg: Int,     // quiet text on the page background
    val edgeOnBg: Int,      // outline of buttons sitting on the background
    val card: Int,          // card background
    val onCard: Int,        // main text in cards
    val muted: Int,         // quiet text in cards
    val soft: Int,          // small labels in cards
    val hint: Int,          // empty text-box hint
    val line: Int,          // outlines and tracks inside cards
    val accent: Int,        // selected pills, sliders, switches, main button
    val onAccent: Int,      // text on accent
    val accentOnBg: Int,    // accent-colored text on the page background
    val ok: Int,            // "armed" green dot
    val armed: Int,         // classic arm circle fill while armed
    val onArmed: Int,
    val armedHint: Int,
    val ringColor: Int,     // classic pulsing ring
    val thumbOff: Int,      // switch thumb when off
    val ripple: Int,
    val cardRadius: Int,    // dp
    val pillRadius: Int,    // dp
    val headFace: Typeface,
    val lightBars: Boolean, // dark status-bar icons
    val dialogTheme: Int,
) {
    companion object {
        private fun c(hex: String) = Color.parseColor(hex)

        val NAMES = listOf("Classic", "Website")

        private val CLASSIC = Look(
            website = false,
            bg = c("#0E0E11"), onBg = Color.WHITE, mutedOnBg = c("#8E8E96"), edgeOnBg = c("#2C2C33"),
            card = c("#1A1A1F"), onCard = Color.WHITE, muted = c("#8E8E96"), soft = c("#C8C8CE"),
            hint = c("#55555C"), line = c("#2C2C33"),
            accent = c("#FF4A32"), onAccent = Color.WHITE, accentOnBg = c("#FF4A32"), ok = c("#3DDC84"),
            armed = c("#FF4A32"), onArmed = Color.WHITE, armedHint = c("#FFD9D3"), ringColor = c("#FF4A32"),
            thumbOff = c("#B0B0B6"), ripple = c("#33FFFFFF"),
            cardRadius = 20, pillRadius = 18,
            headFace = Typeface.DEFAULT_BOLD, lightBars = false,
            dialogTheme = android.R.style.Theme_DeviceDefault_Dialog_Alert,
        )

        // Same colors as the website version (light mode).
        private val WEB_LIGHT = Look(
            website = true,
            bg = c("#F2F1EE"), onBg = c("#16161A"), mutedOnBg = c("#6B6B73"), edgeOnBg = c("#D9D8D3"),
            card = Color.WHITE, onCard = c("#16161A"), muted = c("#6B6B73"), soft = c("#6B6B73"),
            hint = c("#A8A8AE"), line = c("#D9D8D3"),
            accent = c("#E8402A"), onAccent = Color.WHITE, accentOnBg = c("#E8402A"), ok = c("#1F9D55"),
            armed = c("#E8402A"), onArmed = Color.WHITE, armedHint = c("#FFD9D3"), ringColor = c("#E8402A"),
            thumbOff = c("#9A9AA0"), ripple = c("#22000000"),
            cardRadius = 14, pillRadius = 10,
            headFace = Typeface.DEFAULT_BOLD, lightBars = true,
            dialogTheme = android.R.style.Theme_DeviceDefault_Light_Dialog_Alert,
        )

        // Same colors as the website version (dark mode).
        private val WEB_DARK = Look(
            website = true,
            bg = c("#101012"), onBg = c("#F3F2EE"), mutedOnBg = c("#94949C"), edgeOnBg = c("#2C2C32"),
            card = c("#1B1B1F"), onCard = c("#F3F2EE"), muted = c("#94949C"), soft = c("#94949C"),
            hint = c("#55555C"), line = c("#2C2C32"),
            accent = c("#FF5A43"), onAccent = Color.WHITE, accentOnBg = c("#FF5A43"), ok = c("#3DDC84"),
            armed = c("#FF5A43"), onArmed = Color.WHITE, armedHint = c("#FFD9D3"), ringColor = c("#FF5A43"),
            thumbOff = c("#B0B0B6"), ripple = c("#33FFFFFF"),
            cardRadius = 14, pillRadius = 10,
            headFace = Typeface.DEFAULT_BOLD, lightBars = false,
            dialogTheme = android.R.style.Theme_DeviceDefault_Dialog_Alert,
        )

        private const val KEY = "look"

        fun index(ctx: Context) =
            ctx.applicationContext.getSharedPreferences("drop", Context.MODE_PRIVATE)
                .getInt(KEY, 0).coerceIn(0, NAMES.size - 1)

        fun save(ctx: Context, i: Int) =
            ctx.applicationContext.getSharedPreferences("drop", Context.MODE_PRIVATE)
                .edit().putInt(KEY, i).apply()

        /** Website style follows the phone's light/dark mode, like the web version. */
        fun current(ctx: Context): Look {
            if (index(ctx) == 0) return CLASSIC
            val night = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            return if (night == Configuration.UI_MODE_NIGHT_YES) WEB_DARK else WEB_LIGHT
        }
    }
}
