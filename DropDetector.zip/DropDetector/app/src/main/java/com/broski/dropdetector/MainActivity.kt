package com.broski.dropdetector

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0E0E11")
    private val card = Color.parseColor("#1A1A1F")
    private val line = Color.parseColor("#2C2C33")
    private val muted = Color.parseColor("#8E8E96")
    private val red = Color.parseColor("#FF4A32")

    private var d = 1f
    private lateinit var headline: TextView
    private lateinit var subline: TextView
    private lateinit var armCircle: FrameLayout
    private lateinit var armLabel: TextView
    private lateinit var armHint: TextView
    private lateinit var ring: View
    private var pulse: ObjectAnimator? = null
    private lateinit var updateBtn: TextView
    private lateinit var countText: TextView
    private var updating = false

    private fun dp(v: Int) = (v * d).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * d
            if (strokeColor != null) setStroke(dp(2), strokeColor)
        }

    private fun oval(color: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokeColor != null) setStroke(dp(3), strokeColor)
        }

    private fun ripple(content: GradientDrawable) =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), content, null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.decorView.setBackgroundColor(bg)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(56), dp(22), dp(32))
        }

        // Header
        col.addView(TextView(this).apply {
            text = "DROP DETECTOR"
            textSize = 13f
            letterSpacing = 0.2f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
        })
        headline = TextView(this).apply {
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(6), 0, 0)
        }
        col.addView(headline)
        subline = TextView(this).apply {
            textSize = 16f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(12))
        }
        col.addView(subline)

        // Big round arm button with a pulsing ring behind it
        val size = dp(200)
        val stage = FrameLayout(this)
        ring = View(this).apply {
            background = oval(Color.TRANSPARENT, red)
            alpha = 0f
        }
        stage.addView(ring, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

        armCircle = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { toggle() }
        }
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        armLabel = TextView(this).apply {
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        armHint = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
        }
        labels.addView(armLabel)
        labels.addView(armHint)
        armCircle.addView(
            labels,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        stage.addView(armCircle, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        col.addView(stage, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))

        // Message card
        val message = EditText(this).apply {
            setText(DropOverlay.message(this@MainActivity))
            hint = DropOverlay.DEFAULT_MESSAGE
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#55555C"))
            background = null
            setPadding(0, dp(8), 0, 0)
            maxLines = 3
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    DropOverlay.saveMessage(this@MainActivity, s?.toString() ?: "")
                }
            })
        }
        col.addView(sectionCard("Drop message", null, message), spaced())

        // Sensitivity card
        val sensValue = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
        }
        val seek = SeekBar(this).apply {
            max = DropOverlay.SENS_STEPS
            progress = DropOverlay.sensitivity(this@MainActivity)
            progressTintList = ColorStateList.valueOf(red)
            thumbTintList = ColorStateList.valueOf(red)
            progressBackgroundTintList = ColorStateList.valueOf(line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    DropOverlay.saveSensitivity(this@MainActivity, p)
                    sensValue.text = sensName(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sensValue.text = sensName(seek.progress)

        val ends = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ends.addView(small("Chill"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        ends.addView(small("Jumpy").apply { gravity = Gravity.END },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val sensBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(seek, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14); bottomMargin = dp(6) })
            addView(ends)
        }
        col.addView(sectionCard("Sensitivity", sensValue, sensBody), spaced())

        // Drop screen look
        val lookBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("Color"))
            addView(chips(DropOverlay.COLOR_NAMES, DropOverlay.colorIndex(this@MainActivity)) {
                DropOverlay.setColorIndex(this@MainActivity, it)
            })
            addView(label("Text size"))
            addView(chips(DropOverlay.SIZE_NAMES, DropOverlay.sizeIndex(this@MainActivity)) {
                DropOverlay.setSizeIndex(this@MainActivity, it)
            })
            addView(label("Close by itself after"))
            addView(chips(DropOverlay.AUTO_NAMES, DropOverlay.autoIndex(this@MainActivity)) {
                DropOverlay.setAutoIndex(this@MainActivity, it)
            })
        }
        col.addView(sectionCard("Drop screen", null, lookBody), spaced())

        // Alerts
        val alertBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleRow("Say the message out loud", DropOverlay.speakOn(this@MainActivity)) {
                DropOverlay.setSpeak(this@MainActivity, it)
            })
            addView(toggleRow("Vibrate", DropOverlay.vibrateOn(this@MainActivity)) {
                DropOverlay.setVibrate(this@MainActivity, it)
            })
        }
        col.addView(sectionCard("Alerts", null, alertBody), spaced())

        // Drop counter
        countText = TextView(this).apply {
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val countRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(countText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(this@MainActivity).apply {
                text = "Reset"
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(red)
                background = ripple(rounded(Color.TRANSPARENT, 18, line))
                setPadding(dp(18), dp(10), dp(18), dp(10))
                isClickable = true
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Reset drop count?")
                        .setMessage("Your record of shame goes back to 0.")
                        .setPositiveButton("Reset") { _, _ ->
                            DropOverlay.resetCount(this@MainActivity)
                            refreshCount()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            })
        }
        col.addView(sectionCard("Times dropped", null, countRow), spaced())

        // Preview button
        col.addView(TextView(this).apply {
            text = "Preview the black screen"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = ripple(rounded(Color.TRANSPARENT, 28, line))
            setPadding(0, dp(16), 0, dp(16))
            isClickable = true
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) DropOverlay.show(this@MainActivity, realDrop = false)
                else askOverlayPermission()
            }
        }, spaced())

        // Version + update button
        updateBtn = TextView(this).apply {
            text = "Check for updates"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(red)
            background = ripple(rounded(Color.TRANSPARENT, 28))
            setPadding(0, dp(14), 0, dp(14))
            isClickable = true
            setOnClickListener { checkForUpdate() }
        }
        col.addView(updateBtn, spaced())
        col.addView(TextView(this).apply {
            text = "Version ${Updater.currentVersion(this@MainActivity)}"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
            addView(col)
        })
    }

    private fun spaced() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(14) }

    private fun small(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(muted)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#C8C8CE"))
        setPadding(0, dp(14), 0, dp(8))
    }

    /** A row of pill buttons where exactly one is selected. */
    private fun chips(names: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pills = mutableListOf<TextView>()
        fun paint(sel: Int) {
            pills.forEachIndexed { i, v ->
                val on = i == sel
                v.background = ripple(rounded(if (on) red else Color.TRANSPARENT, 18, if (on) red else line))
                v.setTextColor(if (on) Color.WHITE else muted)
            }
        }
        names.forEachIndexed { i, name ->
            val pill = TextView(this).apply {
                text = name
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                isClickable = true
                setOnClickListener { onPick(i); paint(i) }
            }
            pills.add(pill)
            row.addView(pill, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(6)
            })
        }
        paint(selected)
        return row
    }

    private fun toggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val sw = Switch(this).apply {
            isChecked = checked
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.WHITE, Color.parseColor("#B0B0B6"))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(red, line)
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 16f
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
            isClickable = true
            setOnClickListener { sw.toggle() }
        }
    }

    private fun refreshCount() {
        val n = DropOverlay.dropCount(this)
        countText.text = if (n == 1) "1 time" else "$n times"
    }

    private fun sectionCard(title: String, trailing: View?, body: View): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12f
            letterSpacing = 0.15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) header.addView(trailing)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            addView(header)
            addView(body)
        }
    }

    private fun sensName(p: Int) = when {
        p <= 2 -> "Chill"
        p <= 5 -> "Normal"
        p <= 8 -> "Sensitive"
        else -> "Jumpy"
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        super.onPause()
        stopPulse()
    }

    private fun refresh() {
        refreshCount()
        val on = DropService.running
        headline.text = if (on) "Watching." else "Off duty."
        subline.text = if (on) "Drop me and you'll hear about it."
                       else "Arm it and I'll keep watch, even in other apps."
        armCircle.background = ripple(if (on) oval(red) else oval(card, line))
        armLabel.text = if (on) "ARMED" else "ARM"
        armHint.text = if (on) "tap to disarm" else "tap to start"
        armHint.setTextColor(if (on) Color.parseColor("#FFD9D3") else muted)
        if (on) startPulse() else stopPulse()
    }

    private fun startPulse() {
        if (pulse != null) return
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            ring,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.22f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.22f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)
        ).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        ring.alpha = 0f
        ring.scaleX = 1f
        ring.scaleY = 1f
    }

    private fun toggle() {
        if (DropService.running) {
            stopService(Intent(this, DropService::class.java))
            DropService.running = false
            refresh()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            askOverlayPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, DropService::class.java))
        DropService.running = true
        refresh()
    }

    private fun setUpdateText(t: String) = runOnUiThread { updateBtn.text = t }

    private fun checkForUpdate() {
        if (updating) return
        updating = true
        updateBtn.text = "Checking…"
        Thread {
            val result = try { Result.success(Updater.fetchLatest()) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                updating = false
                updateBtn.text = "Check for updates"
                val current = Updater.currentVersion(this)
                val latest = result.getOrNull()
                when {
                    result.isFailure ->
                        toast("Couldn't reach GitHub. Are you online?")
                    latest == null ->
                        toast("No releases on GitHub yet.")
                    latest.number <= current ->
                        toast("You're on the latest version ($current).")
                    else ->
                        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                            .setTitle("Update available")
                            .setMessage("Version ${latest.number} is out. You have $current.")
                            .setPositiveButton("Update") { _, _ -> startUpdate(latest) }
                            .setNegativeButton("Later", null)
                            .show()
                }
            }
        }.start()
    }

    private fun startUpdate(release: Updater.Release) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Allow Drop Detector to install apps, then tap Update again.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        updating = true
        updateBtn.text = "Downloading…"
        Thread {
            try {
                val apk = Updater.download(this, release.apkUrl) { pct ->
                    if (pct >= 0) setUpdateText("Downloading $pct%")
                }
                runOnUiThread {
                    updating = false
                    updateBtn.text = "Check for updates"
                    Updater.install(this, apk)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    updating = false
                    updateBtn.text = "Check for updates"
                    toast("Download failed. Try again.")
                }
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun askOverlayPermission() {
        Toast.makeText(
            this,
            "Turn on \"Display over other apps\" for Drop Detector, then come back.",
            Toast.LENGTH_LONG
        ).show()
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }
}
