package com.broski.dropdetector

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

private const val MATCH = -1  // ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = -2   // ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var look: Look
    private val bg get() = look.bg
    private val card get() = look.card
    private val line get() = look.line
    private val muted get() = look.muted
    private val red get() = look.accent

    private var d = 1f
    private lateinit var headline: TextView
    private lateinit var subline: TextView
    private lateinit var armCircle: FrameLayout
    private lateinit var armLabel: TextView
    private lateinit var armHint: TextView
    private lateinit var ring: View
    private var pulse: ObjectAnimator? = null
    private lateinit var updateBtn: TextView
    private lateinit var countText: TextView
    private var updating = false

    private fun dp(v: Int) = (v * d).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * d
            // Website style uses thin 1dp borders like the web version.
            if (strokeColor != null) setStroke(if (look.website) dp(1) else dp(2), strokeColor)
        }

    private fun oval(color: Int, strokeColor: Int? = null) =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokeColor != null) setStroke(dp(3), strokeColor)
        }

    private fun ripple(content: GradientDrawable) =
        RippleDrawable(ColorStateList.valueOf(look.ripple), content, null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        look = Look.current(this)
        DropOverlay.loadThreshold(this)
        window.decorView.setBackgroundColor(bg)
        setBarIcons()

        if (look.website) {
            buildWebsite(savedInstanceState?.getInt("tab", 0) ?: 0)
            return
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(56), dp(22), dp(32))
        }

        run {
        // Header
        col.addView(TextView(this).apply {
            text = "DROP DETECTOR"
            textSize = 13f
            letterSpacing = 0.2f
            typeface = look.headFace
            setTextColor(look.mutedOnBg)
        })
        headline = TextView(this).apply {
            textSize = 40f
            typeface = look.headFace
            setTextColor(look.onBg)
            setPadding(0, dp(6), 0, 0)
        }
        col.addView(headline)
        subline = TextView(this).apply {
            textSize = 16f
            setTextColor(look.mutedOnBg)
            setPadding(0, dp(4), 0, dp(12))
        }
        col.addView(subline)

        // Big round arm button with a pulsing ring behind it
        val size = dp(200)
        val stage = FrameLayout(this)
        ring = View(this).apply {
            background = oval(Color.TRANSPARENT, look.ringColor)
            alpha = 0f
        }
        stage.addView(ring, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

        armCircle = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { toggle() }
        }
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        armLabel = TextView(this).apply {
            textSize = 28f
            typeface = look.headFace
            gravity = Gravity.CENTER
        }
        armHint = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
        }
        labels.addView(armLabel)
        labels.addView(armHint)
        armCircle.addView(
            labels,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        stage.addView(armCircle, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        col.addView(stage, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))
        }

        // Message card
        val message = EditText(this).apply {
            setText(DropOverlay.message(this@MainActivity))
            hint = DropOverlay.DEFAULT_MESSAGE
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(look.onCard)
            setHintTextColor(look.hint)
            background = null
            setPadding(0, dp(8), 0, 0)
            maxLines = 3
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    DropOverlay.saveMessage(this@MainActivity, s?.toString() ?: "")
                }
            })
        }
        col.addView(sectionCard("Drop message", null, message), spaced())

        // Sensitivity card
        val sensValue = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
        }
        val seek = SeekBar(this).apply {
            max = DropOverlay.SENS_STEPS
            progress = DropOverlay.sensitivity(this@MainActivity)
            progressTintList = ColorStateList.valueOf(red)
            thumbTintList = ColorStateList.valueOf(red)
            progressBackgroundTintList = ColorStateList.valueOf(line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    DropOverlay.saveSensitivity(this@MainActivity, p)
                    sensValue.text = sensName(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sensValue.text = sensName(seek.progress)

        val ends = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ends.addView(small("Chill"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        ends.addView(small("Jumpy").apply { gravity = Gravity.END },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val sensBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(seek, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14); bottomMargin = dp(6) })
            addView(ends)
        }
        col.addView(sectionCard("Sensitivity", sensValue, sensBody), spaced())

        // Drop screen look
        val lookBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("Color"))
            addView(chips(DropOverlay.COLOR_NAMES, DropOverlay.colorIndex(this@MainActivity)) {
                DropOverlay.setColorIndex(this@MainActivity, it)
            })
            addView(label("Text size"))
            addView(chips(DropOverlay.SIZE_NAMES, DropOverlay.sizeIndex(this@MainActivity)) {
                DropOverlay.setSizeIndex(this@MainActivity, it)
            })
            addView(label("Close by itself after"))
            addView(chips(DropOverlay.AUTO_NAMES, DropOverlay.autoIndex(this@MainActivity)) {
                DropOverlay.setAutoIndex(this@MainActivity, it)
            })
        }
        col.addView(sectionCard("Drop screen", null, lookBody), spaced())

        // Alerts
        val alertBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleRow("Say the message out loud", DropOverlay.speakOn(this@MainActivity)) {
                DropOverlay.setSpeak(this@MainActivity, it)
            })
            addView(toggleRow("Vibrate", DropOverlay.vibrateOn(this@MainActivity)) {
                DropOverlay.setVibrate(this@MainActivity, it)
            })
        }
        col.addView(sectionCard("Alerts", null, alertBody), spaced())

        // Drop counter
        countText = TextView(this).apply {
            textSize = 34f
            typeface = look.headFace
            setTextColor(look.onCard)
        }
        val countRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
            addView(countText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(this@MainActivity).apply {
                text = "Reset"
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(red)
                background = ripple(rounded(Color.TRANSPARENT, look.pillRadius, line))
                setPadding(dp(18), dp(10), dp(18), dp(10))
                isClickable = true
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity, look.dialogTheme)
                        .setTitle("Reset drop count?")
                        .setMessage("Your record of shame goes back to 0.")
                        .setPositiveButton("Reset") { _, _ ->
                            DropOverlay.resetCount(this@MainActivity)
                            refreshCount()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            })
        }
        col.addView(sectionCard("Times dropped", null, countRow), spaced())

        // App style (optional new look)
        val styleBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(chips(Look.NAMES, Look.index(this@MainActivity)) { i ->
                if (i != Look.index(this@MainActivity)) {
                    Look.save(this@MainActivity, i)
                    recreate()
                }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = "Website matches the web version and follows your phone's light or dark mode. Your settings stay the same."
                textSize = 13f
                setTextColor(look.soft)
                setPadding(0, dp(10), 0, 0)
            })
        }
        col.addView(sectionCard("App style", null, styleBody), spaced())

        // Preview button
        col.addView(TextView(this).apply {
            text = "Preview the black screen"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(look.onBg)
            background = ripple(rounded(Color.TRANSPARENT, if (look.website) look.cardRadius else 28, look.edgeOnBg))
            setPadding(0, dp(16), 0, dp(16))
            isClickable = true
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) DropOverlay.show(this@MainActivity, realDrop = false)
                else askOverlayPermission()
            }
        }, spaced())

        // Version + update button
        updateBtn = TextView(this).apply {
            text = "Check for updates"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(look.accentOnBg)
            background = ripple(rounded(Color.TRANSPARENT, 28))
            setPadding(0, dp(14), 0, dp(14))
            isClickable = true
            setOnClickListener { checkForUpdate() }
        }
        col.addView(updateBtn, spaced())
        col.addView(TextView(this).apply {
            text = "Version ${Updater.currentVersion(this@MainActivity)}"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(look.mutedOnBg)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
            addView(col)
        })
    }

    private fun setBarIcons() {
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (look.lightBars) mask else 0, mask)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                if (look.lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        }
        @Suppress("DEPRECATION")
        window.statusBarColor = look.bg
        @Suppress("DEPRECATION")
        window.navigationBarColor = look.bg
    }

    private fun spaced() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(14) }

    private fun small(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(muted)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(look.soft)
        setPadding(0, dp(14), 0, dp(8))
    }

    /** A row of pill buttons where exactly one is selected. */
    private fun chips(names: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pills = mutableListOf<TextView>()
        fun paint(sel: Int) {
            pills.forEachIndexed { i, v ->
                val on = i == sel
                v.background = ripple(rounded(if (on) red else Color.TRANSPARENT, look.pillRadius, if (on) red else line))
                v.setTextColor(if (on) look.onAccent else muted)
            }
        }
        names.forEachIndexed { i, name ->
            val pill = TextView(this).apply {
                text = name
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                isClickable = true
                setOnClickListener { onPick(i); paint(i) }
            }
            pills.add(pill)
            row.addView(pill, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(6)
            })
        }
        paint(selected)
        return row
    }

    private fun toggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val sw = Switch(this).apply {
            isChecked = checked
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(look.onAccent, look.thumbOff)
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(red, line)
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(4))
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 16f
                setTextColor(look.onCard)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(sw)
            isClickable = true
            setOnClickListener { sw.toggle() }
        }
    }

    private fun refreshCount() {
        val n = DropOverlay.dropCount(this)
        countText.text = if (n == 1) "1 time" else "$n times"
    }

    private fun sectionCard(title: String, trailing: View?, body: View): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            if (look.website) {
                text = title
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(look.onCard)
            } else {
                text = title.uppercase()
                textSize = 12f
                letterSpacing = 0.15f
                typeface = look.headFace
                setTextColor(muted)
            }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) header.addView(trailing)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = if (look.website) rounded(card, look.cardRadius, line) else rounded(card, look.cardRadius)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            addView(header)
            addView(body)
        }
    }

    private fun sensName(p: Int) = when {
        p <= 2 -> "Chill"
        p <= 5 -> "Normal"
        p <= 8 -> "Sensitive"
        else -> "Jumpy"
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (look.website) {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            sensors = sm
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm.registerListener(graphListener, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        stopPulse()
        dotPulse?.cancel()
        dotPulse = null
        sensors?.unregisterListener(graphListener)
    }

    // The drop screen covers the app without pausing it, so refresh when it closes.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", currentTab)
    }

    private fun refresh() {
        val on = DropService.running
        if (look.website) { refreshWeb(on); return }
        refreshCount()
        headline.text = if (on) "Watching." else "Off duty."
        subline.text = if (on) "Drop me and you'll hear about it."
                       else "Arm it and I'll keep watch, even in other apps."
        armCircle.background = ripple(if (on) oval(look.armed) else oval(card, line))
        armLabel.setTextColor(if (on) look.onArmed else look.onCard)
        armLabel.text = if (on) "ARMED" else "ARM"
        armHint.text = if (on) "tap to disarm" else "tap to start"
        armHint.setTextColor(if (on) look.armedHint else muted)
        if (on) startPulse() else stopPulse()
    }

    // =====================================================================
    // Website style: header with status pill, Home / History / Settings tabs
    // =====================================================================

    private val pages = mutableListOf<View>()
    private val tabLabels = mutableListOf<TextView>()
    private val tabBars = mutableListOf<View>()
    private var currentTab = 0
    private var pillDot: View? = null
    private var pillText: TextView? = null
    private var heroDot: View? = null
    private var heroTitle: TextView? = null
    private var heroSub: TextView? = null
    private var webArm: TextView? = null
    private var dotPulse: ObjectAnimator? = null
    private var graph: ForceGraphView? = null
    private var gText: TextView? = null
    private var sampleTick = 0
    private var statDrops: TextView? = null
    private var statBest: TextView? = null
    private var statLast: TextView? = null
    private var historyTitle: TextView? = null
    private var historyList: LinearLayout? = null
    private var previewFrame: FrameLayout? = null
    private var previewMsg: TextView? = null
    private var previewCount: TextView? = null
    private var sensors: SensorManager? = null

    private val graphListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val x = e.values[0]
            val y = e.values[1]
            val z = e.values[2]
            val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
            graph?.push(g)
            sampleTick++
            val falling = g < DropOverlay.thresholdG
            if (falling || sampleTick % 6 == 0) {
                gText?.text = String.format("%.2f g", g)
                gText?.setTextColor(if (falling) red else look.onCard)
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun buildWebsite(startTab: Int) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        // Header: title + live status pill
        val pDot = View(this)
        pillDot = pDot
        val pText = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(look.onCard)
        }
        pillText = pText
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(card, 99, line)
            setPadding(dp(12), dp(7), dp(14), dp(7))
            addView(pDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
            addView(pText)
        }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(52), dp(20), dp(8))
            addView(TextView(this@MainActivity).apply {
                text = "Drop detector"
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(look.onBg)
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(pill)
        })

        // Nav tabs, like a website menu
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), 0, dp(20), 0)
        }
        listOf("Home", "History", "Settings").forEachIndexed { i, name ->
            val lbl = TextView(this).apply {
                text = name
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(10))
            }
            val bar = View(this).apply { background = rounded(red, 2) }
            tabLabels.add(lbl)
            tabBars.add(bar)
            nav.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                isClickable = true
                setOnClickListener { showTab(i) }
                addView(lbl)
                addView(bar, LinearLayout.LayoutParams(MATCH, dp(3)))
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(24) })
        }
        root.addView(nav)
        root.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(MATCH, dp(1)))

        // Pages
        val content = FrameLayout(this)
        listOf(buildHomePage(), buildHistoryPage(), buildSettingsPage()).forEach { page ->
            val scroll = ScrollView(this).apply {
                isFillViewport = true
                addView(page)
            }
            pages.add(scroll)
            content.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)
        showTab(startTab, animate = false)
    }

    private fun showTab(i: Int, animate: Boolean = true) {
        currentTab = i.coerceIn(0, pages.size - 1)
        pages.forEachIndexed { idx, p ->
            if (idx == currentTab) {
                p.visibility = View.VISIBLE
                if (animate) {
                    p.alpha = 0f
                    p.translationY = dp(10).toFloat()
                    p.animate().alpha(1f).translationY(0f).setDuration(200).start()
                }
            } else {
                p.visibility = View.GONE
            }
        }
        tabLabels.forEachIndexed { idx, t -> t.setTextColor(if (idx == currentTab) look.onBg else look.mutedOnBg) }
        tabBars.forEachIndexed { idx, b -> b.visibility = if (idx == currentTab) View.VISIBLE else View.INVISIBLE }
        if (currentTab == 1) refreshHistory()
    }

    private fun pageColumn() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(6), dp(20), dp(40))
    }

    private fun webCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card, look.cardRadius, line)
        setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    private fun caption(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(muted)
        setPadding(0, dp(10), 0, 0)
    }

    private fun outlineButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(look.onBg)
        background = ripple(rounded(Color.TRANSPARENT, look.cardRadius, look.edgeOnBg))
        setPadding(0, dp(15), 0, dp(15))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun previewDropScreen() {
        if (Settings.canDrawOverlays(this)) DropOverlay.show(this, realDrop = false)
        else askOverlayPermission()
    }

    // ---------- Home ----------

    private fun buildHomePage(): LinearLayout {
        val col = pageColumn()

        // Hero: status + big arm button
        val hDot = View(this)
        heroDot = hDot
        val hTitle = TextView(this).apply {
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(look.onCard)
        }
        heroTitle = hTitle
        val hSub = TextView(this).apply {
            textSize = 15f
            setTextColor(muted)
            setPadding(0, dp(6), 0, 0)
        }
        heroSub = hSub
        val arm = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(17), 0, dp(17))
            isClickable = true
            setOnClickListener { v ->
                v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }.start()
                toggle()
            }
        }
        webArm = arm
        val hero = webCard().apply {
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(hDot, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(12) })
                addView(hTitle)
            })
            addView(hSub)
            addView(arm, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })
        }
        col.addView(hero, spaced())

        // Live force graph
        val gv = TextView(this).apply {
            text = "–"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(look.onCard)
        }
        gText = gv
        val fg = ForceGraphView(this, look)
        graph = fg
        col.addView(webCard().apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(this@MainActivity).apply {
                    text = "Live force"
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(look.onCard)
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(gv)
            })
            addView(fg, LinearLayout.LayoutParams(MATCH, dp(150)).apply { topMargin = dp(12) })
            addView(caption("Move your phone to see it change. Dips below the red line count as a fall."))
        }, spaced())

        // Stats row
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun stat(name: String, i: Int): TextView {
            val v = TextView(this).apply {
                text = "–"
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(look.onCard)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(card, look.cardRadius, line)
                setPadding(dp(14), dp(14), dp(10), dp(14))
                addView(v)
                addView(TextView(this@MainActivity).apply {
                    text = name
                    textSize = 12f
                    setTextColor(muted)
                    setPadding(0, dp(4), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i > 0) marginStart = dp(10) })
            return v
        }
        statDrops = stat("Drops", 0)
        statBest = stat("Biggest fall", 1)
        statLast = stat("Last drop", 2)
        col.addView(row, spaced())

        col.addView(outlineButton("Preview drop screen") { previewDropScreen() }, spaced())
        return col
    }

    // ---------- History ----------

    private fun buildHistoryPage(): LinearLayout {
        val col = pageColumn()
        val title = TextView(this).apply {
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(look.onBg)
            setPadding(0, dp(14), 0, 0)
        }
        historyTitle = title
        col.addView(title)
        col.addView(TextView(this).apply {
            text = "Fall height is a rough guess from how long your phone was in free fall."
            textSize = 14f
            setTextColor(look.mutedOnBg)
            setPadding(0, dp(6), 0, 0)
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyList = list
        col.addView(list, spaced())
        col.addView(outlineButton("Clear history") { confirmClear() }, spaced())
        return col
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, look.dialogTheme)
            .setTitle("Clear history?")
            .setMessage("This deletes the drop log and sets your drop count back to 0.")
            .setPositiveButton("Clear") { _, _ ->
                DropOverlay.clearHistory(this)
                refresh()
                refreshHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshHistory() {
        val list = historyList ?: return
        val falls = DropOverlay.history(this)
        val total = DropOverlay.dropCount(this)
        historyTitle?.text = when (total) {
            0 -> "No drops yet"
            1 -> "1 drop"
            else -> "$total drops"
        }
        list.removeAllViews()
        if (falls.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (total == 0) "Keep it that way, broski."
                       else "Drops from before this update aren't in the log. New ones will show up here."
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(muted)
                background = rounded(card, look.cardRadius, line)
                setPadding(dp(20), dp(28), dp(20), dp(28))
            })
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, look.cardRadius, line)
        }
        falls.forEachIndexed { i, f ->
            if (i > 0) {
                box.addView(View(this).apply { setBackgroundColor(line) },
                    LinearLayout.LayoutParams(MATCH, dp(1)).apply { marginStart = dp(18) })
            }
            box.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(14), dp(18), dp(14))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(this@MainActivity).apply {
                        text = "Drop #${f.number}"
                        textSize = 16f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(look.onCard)
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = whenText(f.time)
                        textSize = 13f
                        setTextColor(muted)
                    })
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.END
                    addView(TextView(this@MainActivity).apply {
                        text = heightText(f.cm)
                        textSize = 16f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(red)
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = String.format("%.2f s fall", f.ms / 1000f)
                        textSize = 13f
                        setTextColor(muted)
                    })
                })
            })
        }
        list.addView(box)
    }

    private fun heightText(cm: Int) =
        if (cm >= 100) String.format("≈ %.1f m", cm / 100f) else "≈ $cm cm"

    private fun whenText(t: Long): String {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
        return when {
            DateUtils.isToday(t) -> "Today, $time"
            DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> "Yesterday, $time"
            else -> SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(t))
        }
    }

    private fun shortAgo(t: Long): String {
        val s = (System.currentTimeMillis() - t) / 1000
        return when {
            s < 60 -> "Just now"
            s < 3600 -> "${s / 60} min ago"
            s < 86400 -> "${s / 3600} h ago"
            else -> "${s / 86400} d ago"
        }
    }

    // ---------- Settings ----------

    private fun buildSettingsPage(): LinearLayout {
        val col = pageColumn()

        // Drop screen card with a live mini preview
        val pMsg = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
        }
        val pCount = TextView(this).apply {
            setTextColor(Color.argb(180, 255, 255, 255))
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        previewMsg = pMsg
        previewCount = pCount
        val frame = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { previewDropScreen() }
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(pMsg)
                addView(pCount)
            }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
            addView(TextView(this@MainActivity).apply {
                text = "tap to dismiss"
                textSize = 7f
                gravity = Gravity.CENTER
                setTextColor(Color.argb(128, 255, 255, 255))
                setPadding(0, 0, 0, dp(12))
            }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        }
        previewFrame = frame

        val message = EditText(this).apply {
            setText(DropOverlay.message(this@MainActivity))
            hint = DropOverlay.DEFAULT_MESSAGE
            textSize = 17f
            setTextColor(look.onCard)
            setHintTextColor(look.hint)
            background = rounded(bg, 10, line)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            maxLines = 3
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    DropOverlay.saveMessage(this@MainActivity, s?.toString() ?: "")
                    updatePreview()
                }
            })
        }

        val screenBody = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(14), 0, 0)
                addView(frame, LinearLayout.LayoutParams(dp(150), dp(266)))
                addView(TextView(this@MainActivity).apply {
                    text = "Tap the preview to try it full screen"
                    textSize = 12f
                    setTextColor(muted)
                    setPadding(0, dp(8), 0, 0)
                })
            })
            addView(label("Message"))
            addView(message)
            addView(label("Color"))
            addView(chips(DropOverlay.COLOR_NAMES, DropOverlay.colorIndex(this@MainActivity)) {
                DropOverlay.setColorIndex(this@MainActivity, it)
                updatePreview()
            })
            addView(label("Text size"))
            addView(chips(DropOverlay.SIZE_NAMES, DropOverlay.sizeIndex(this@MainActivity)) {
                DropOverlay.setSizeIndex(this@MainActivity, it)
                updatePreview()
            })
            addView(label("Close by itself after"))
            addView(chips(DropOverlay.AUTO_NAMES, DropOverlay.autoIndex(this@MainActivity)) {
                DropOverlay.setAutoIndex(this@MainActivity, it)
            })
        }
        col.addView(sectionCard("Drop screen", null, screenBody), spaced())

        // Sensitivity
        val sensValue = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
        }
        val seek = SeekBar(this).apply {
            max = DropOverlay.SENS_STEPS
            progress = DropOverlay.sensitivity(this@MainActivity)
            progressTintList = ColorStateList.valueOf(red)
            thumbTintList = ColorStateList.valueOf(red)
            progressBackgroundTintList = ColorStateList.valueOf(line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    DropOverlay.saveSensitivity(this@MainActivity, p)
                    sensValue.text = sensName(p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sensValue.text = sensName(seek.progress)
        val ends = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ends.addView(small("Chill"), LinearLayout.LayoutParams(0, WRAP, 1f))
        ends.addView(small("Jumpy").apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(sectionCard("Sensitivity", sensValue, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(seek, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14); bottomMargin = dp(6) })
            addView(ends)
            addView(caption("The red line on the Home graph moves as you slide this."))
        }), spaced())

        // Alerts
        col.addView(sectionCard("Alerts", null, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(toggleRow("Say the message out loud", DropOverlay.speakOn(this@MainActivity)) {
                DropOverlay.setSpeak(this@MainActivity, it)
            })
            addView(toggleRow("Vibrate", DropOverlay.vibrateOn(this@MainActivity)) {
                DropOverlay.setVibrate(this@MainActivity, it)
            })
        }), spaced())

        // App style
        col.addView(sectionCard("App style", null, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(chips(Look.NAMES, Look.index(this@MainActivity)) { i ->
                if (i != Look.index(this@MainActivity)) {
                    Look.save(this@MainActivity, i)
                    recreate()
                }
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            addView(caption("Website follows your phone's light or dark mode. Classic is the original look."))
        }), spaced())

        // About + updates
        val upd = TextView(this).apply {
            text = "Check for updates"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(red)
            background = ripple(rounded(Color.TRANSPARENT, look.cardRadius, line))
            setPadding(0, dp(13), 0, dp(13))
            isClickable = true
            setOnClickListener { checkForUpdate() }
        }
        updateBtn = upd
        col.addView(sectionCard("About", null, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "Drop Detector, version ${Updater.currentVersion(this@MainActivity)}"
                textSize = 15f
                setTextColor(look.onCard)
                setPadding(0, dp(8), 0, dp(12))
            })
            addView(upd, LinearLayout.LayoutParams(MATCH, WRAP))
        }), spaced())

        updatePreview()
        return col
    }

    private fun updatePreview() {
        previewFrame?.background = GradientDrawable().apply {
            setColor(DropOverlay.colorFor(DropOverlay.colorIndex(this@MainActivity)))
            cornerRadius = 22f * d
            setStroke(dp(5), look.line)
        }
        previewMsg?.text = DropOverlay.message(this)
        previewMsg?.textSize = DropOverlay.textSizeFor(DropOverlay.sizeIndex(this)) * 0.34f
        val n = DropOverlay.dropCount(this)
        previewCount?.text = "Drop #$n"
        previewCount?.visibility = if (n > 0) View.VISIBLE else View.GONE
    }

    // ---------- Website refresh ----------

    private fun refreshWeb(on: Boolean) {
        val dotColor = if (on) look.ok else look.muted
        pillDot?.background = oval(dotColor)
        heroDot?.background = oval(dotColor)
        pillText?.text = if (on) "Armed" else "Off"
        heroTitle?.text = if (on) "Armed" else "Not armed"
        heroSub?.text = if (on) "Watching for drops, even in other apps. Don't you dare."
                        else "Tap Arm it and I'll watch for drops in the background."
        webArm?.apply {
            text = if (on) "Disarm" else "Arm it"
            background = ripple(if (on) rounded(card, look.cardRadius, line) else rounded(red, look.cardRadius))
            setTextColor(if (on) look.onCard else look.onAccent)
        }

        dotPulse?.cancel()
        dotPulse = null
        heroDot?.alpha = 1f
        val hd = heroDot
        if (on && hd != null) {
            dotPulse = ObjectAnimator.ofFloat(hd, View.ALPHA, 1f, 0.3f).apply {
                duration = 900
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        }

        val n = DropOverlay.dropCount(this)
        val falls = DropOverlay.history(this)
        statDrops?.text = n.toString()
        statBest?.text = falls.maxOfOrNull { it.cm }?.let { heightText(it).removePrefix("≈ ") } ?: "–"
        statLast?.text = falls.firstOrNull()?.let { shortAgo(it.time) } ?: (if (n > 0) "Earlier" else "Never")
        if (currentTab == 1) refreshHistory()
        updatePreview()
    }

    // ---------- Classic style ----------

    private fun startPulse() {
        if (pulse != null) return
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            ring,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.22f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.22f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.8f, 0f)
        ).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopPulse() {
        pulse?.cancel()
        pulse = null
        if (!::ring.isInitialized) return
        ring.alpha = 0f
        ring.scaleX = 1f
        ring.scaleY = 1f
    }

    private fun toggle() {
        if (DropService.running) {
            stopService(Intent(this, DropService::class.java))
            DropService.running = false
            refresh()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            askOverlayPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, DropService::class.java))
        DropService.running = true
        refresh()
    }

    private fun setUpdateText(t: String) = runOnUiThread { updateBtn.text = t }

    private fun checkForUpdate() {
        if (updating) return
        updating = true
        updateBtn.text = "Checking…"
        Thread {
            val result = try { Result.success(Updater.fetchLatest()) } catch (e: Exception) { Result.failure(e) }
            runOnUiThread {
                updating = false
                updateBtn.text = "Check for updates"
                val current = Updater.currentVersion(this)
                val latest = result.getOrNull()
                when {
                    result.isFailure ->
                        toast("Couldn't reach GitHub. Are you online?")
                    latest == null ->
                        toast("No releases on GitHub yet.")
                    latest.number <= current ->
                        toast("You're on the latest version ($current).")
                    else ->
                        AlertDialog.Builder(this, look.dialogTheme)
                            .setTitle("Update available")
                            .setMessage("Version ${latest.number} is out. You have $current.")
                            .setPositiveButton("Update") { _, _ -> startUpdate(latest) }
                            .setNegativeButton("Later", null)
                            .show()
                }
            }
        }.start()
    }

    private fun startUpdate(release: Updater.Release) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Allow Drop Detector to install apps, then tap Update again.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        updating = true
        updateBtn.text = "Downloading…"
        Thread {
            try {
                val apk = Updater.download(this, release.apkUrl) { pct ->
                    if (pct >= 0) setUpdateText("Downloading $pct%")
                }
                runOnUiThread {
                    updating = false
                    updateBtn.text = "Check for updates"
                    Updater.install(this, apk)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    updating = false
                    updateBtn.text = "Check for updates"
                    toast("Download failed. Try again.")
                }
            }
        }.start()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun askOverlayPermission() {
        Toast.makeText(
            this,
            "Turn on \"Display over other apps\" for Drop Detector, then come back.",
            Toast.LENGTH_LONG
        ).show()
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }
}
