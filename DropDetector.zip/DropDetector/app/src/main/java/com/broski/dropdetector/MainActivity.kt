package com.broski.dropdetector

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var armBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
            setBackgroundColor(Color.parseColor("#101012"))
        }

        root.addView(TextView(this).apply {
            text = "Drop detector"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })

        root.addView(TextView(this).apply {
            text = "Arm it and it keeps watching, even when you're in other apps. " +
                "Drop the phone and the screen goes black."
            textSize = 16f
            setTextColor(Color.parseColor("#94949C"))
            setPadding(0, (8 * d).toInt(), 0, (24 * d).toInt())
        })

        status = TextView(this).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, (20 * d).toInt())
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "Drop message"
            textSize = 14f
            setTextColor(Color.parseColor("#94949C"))
        })

        root.addView(EditText(this).apply {
            setText(DropOverlay.message(this@MainActivity))
            hint = DropOverlay.DEFAULT_MESSAGE
            textSize = 18f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#55555C"))
            setSingleLine(false)
            maxLines = 4
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    DropOverlay.saveMessage(this@MainActivity, s?.toString() ?: "")
                }
            })
        })

        root.addView(TextView(this).apply {
            text = "Saves as you type. Leave it empty to use the default."
            textSize = 13f
            setTextColor(Color.parseColor("#94949C"))
            setPadding(0, 0, 0, (20 * d).toInt())
        })

        armBtn = Button(this).apply { textSize = 18f; setOnClickListener { toggle() } }
        root.addView(armBtn)

        root.addView(Button(this).apply {
            text = "Preview the black screen"
            setOnClickListener {
                if (hasOverlayPermission()) DropOverlay.show(this@MainActivity)
                else askOverlayPermission()
            }
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        if (DropService.running) {
            status.text = "Armed. Watching for drops."
            status.setTextColor(Color.parseColor("#3DDC84"))
            armBtn.text = "Disarm"
        } else {
            status.text = "Not armed"
            status.setTextColor(Color.parseColor("#94949C"))
            armBtn.text = "Arm it"
        }
    }

    private fun toggle() {
        if (DropService.running) {
            stopService(Intent(this, DropService::class.java))
            DropService.running = false
            refresh()
            return
        }
        if (!hasOverlayPermission()) {
            askOverlayPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, DropService::class.java))
        DropService.running = true
        refresh()
    }

    private fun hasOverlayPermission() = Settings.canDrawOverlays(this)

    private fun askOverlayPermission() {
        Toast.makeText(
            this,
            "Turn on \"Display over other apps\" for Drop Detector, then come back.",
            Toast.LENGTH_LONG
        ).show()
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }
}
