package com.broski.dropdetector

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min
import kotlin.math.roundToInt

/** The drop screen drawn on top of every app, plus all saved settings. */
object DropOverlay {

    const val DEFAULT_MESSAGE = "dont drop me again broski"
    private const val PREFS = "drop"
    private const val KEY_MESSAGE = "message"
    private const val KEY_SENS = "sensitivity"
    private const val KEY_SPEAK = "speak"
    private const val KEY_VIBRATE = "vibrate"
    private const val KEY_COLOR = "color"
    private const val KEY_SIZE = "size"
    private const val KEY_AUTO = "auto_dismiss"
    private const val KEY_COUNT = "drop_count"
    private const val KEY_LOG = "drop_log"
    private const val LOG_MAX = 50

    // Choices shown in the app. Index is what gets saved.
    val COLOR_NAMES = listOf("Black", "Red", "Blue", "Purple")
    private val COLORS = listOf("#000000", "#B3120A", "#0B2A8F", "#4A0E7A")
    val SIZE_NAMES = listOf("Small", "Medium", "Huge")
    private val SIZES = listOf(32f, 44f, 64f)
    val AUTO_NAMES = listOf("Off", "3 s", "5 s", "10 s")
    private val AUTO_MS = listOf(0L, 3000L, 5000L, 10000L)

    // Sensitivity: slider steps 0..10 map to a free-fall threshold of 0.15..0.65 g.
    // Higher threshold = triggers more easily. Default step 4 = 0.35 g.
    const val SENS_STEPS = 10
    private const val DEFAULT_SENS = 4

    @Volatile var thresholdG = 0.35f
        private set

    private var view: View? = null
    private var shownAt = 0L
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- settings ----

    fun message(ctx: Context): String {
        val saved = prefs(ctx).getString(KEY_MESSAGE, null)
        return if (saved.isNullOrBlank()) DEFAULT_MESSAGE else saved
    }
    fun saveMessage(ctx: Context, text: String) = prefs(ctx).edit().putString(KEY_MESSAGE, text).apply()

    fun sensitivity(ctx: Context): Int = prefs(ctx).getInt(KEY_SENS, DEFAULT_SENS).coerceIn(0, SENS_STEPS)
    fun saveSensitivity(ctx: Context, step: Int) {
        prefs(ctx).edit().putInt(KEY_SENS, step).apply()
        thresholdG = toG(step)
    }
    fun loadThreshold(ctx: Context) { thresholdG = toG(sensitivity(ctx)) }
    private fun toG(step: Int) = 0.15f + 0.05f * step.coerceIn(0, SENS_STEPS)

    fun getBool(ctx: Context, key: String) = prefs(ctx).getBoolean(key, true)
    fun setBool(ctx: Context, key: String, v: Boolean) = prefs(ctx).edit().putBoolean(key, v).apply()
    fun speakOn(ctx: Context) = getBool(ctx, KEY_SPEAK)
    fun setSpeak(ctx: Context, v: Boolean) = setBool(ctx, KEY_SPEAK, v)
    fun vibrateOn(ctx: Context) = getBool(ctx, KEY_VIBRATE)
    fun setVibrate(ctx: Context, v: Boolean) = setBool(ctx, KEY_VIBRATE, v)

    private fun getIndex(ctx: Context, key: String, def: Int, max: Int) =
        prefs(ctx).getInt(key, def).coerceIn(0, max)
    private fun setIndex(ctx: Context, key: String, v: Int) = prefs(ctx).edit().putInt(key, v).apply()

    fun colorIndex(ctx: Context) = getIndex(ctx, KEY_COLOR, 0, COLORS.size - 1)
    fun setColorIndex(ctx: Context, i: Int) = setIndex(ctx, KEY_COLOR, i)
    fun sizeIndex(ctx: Context) = getIndex(ctx, KEY_SIZE, 1, SIZES.size - 1)
    fun setSizeIndex(ctx: Context, i: Int) = setIndex(ctx, KEY_SIZE, i)
    fun autoIndex(ctx: Context) = getIndex(ctx, KEY_AUTO, 0, AUTO_MS.size - 1)
    fun setAutoIndex(ctx: Context, i: Int) = setIndex(ctx, KEY_AUTO, i)

    fun dropCount(ctx: Context) = prefs(ctx).getInt(KEY_COUNT, 0)
    fun resetCount(ctx: Context) = prefs(ctx).edit().putInt(KEY_COUNT, 0).apply()

    fun colorFor(i: Int) = Color.parseColor(COLORS[i.coerceIn(0, COLORS.size - 1)])
    fun textSizeFor(i: Int) = SIZES[i.coerceIn(0, SIZES.size - 1)]

    // ---- drop log ----

    /** One logged drop. Fall height is estimated from free-fall time: h = ½·g·t². */
    class Fall(val number: Int, val time: Long, val ms: Long) {
        val cm: Int get() {
            val t = ms / 1000.0
            return (0.5 * 9.81 * t * t * 100).roundToInt()
        }
    }

    private fun readLog(ctx: Context): JSONArray =
        try { JSONArray(prefs(ctx).getString(KEY_LOG, "[]")) } catch (e: Exception) { JSONArray() }

    /** Called by the service once the phone lands. Newest first, keeps the last 50. */
    fun recordFall(ctx: Context, startWallTime: Long, ms: Long) {
        val old = readLog(ctx)
        val out = JSONArray()
        out.put(JSONObject().put("n", dropCount(ctx)).put("t", startWallTime).put("ms", ms))
        for (i in 0 until min(old.length(), LOG_MAX - 1)) out.put(old.get(i))
        prefs(ctx).edit().putString(KEY_LOG, out.toString()).apply()
    }

    fun history(ctx: Context): List<Fall> {
        val arr = readLog(ctx)
        val list = ArrayList<Fall>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(Fall(o.optInt("n"), o.optLong("t"), o.optLong("ms")))
        }
        return list
    }

    fun clearHistory(ctx: Context) =
        prefs(ctx).edit().remove(KEY_LOG).putInt(KEY_COUNT, 0).apply()

    // ---- the drop screen ----

    /** realDrop = true counts it as a drop; previews pass false. */
    fun show(ctx: Context, realDrop: Boolean) {
        val app = ctx.applicationContext
        if (view != null || !Settings.canDrawOverlays(app)) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = app.resources.displayMetrics.density

        var count = dropCount(app)
        if (realDrop) {
            count += 1
            prefs(app).edit().putInt(KEY_COUNT, count).apply()
        }

        val frame = FrameLayout(app).apply {
            setBackgroundColor(Color.parseColor(COLORS[colorIndex(app)]))
        }

        val center = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        center.addView(TextView(app).apply {
            text = message(app)
            setTextColor(Color.WHITE)
            textSize = SIZES[sizeIndex(app)]
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val p = (32 * d).toInt()
            setPadding(p, p, p, (12 * d).toInt())
        })
        if (count > 0) {
            center.addView(TextView(app).apply {
                text = if (count == 1) "Drop #1" else "Drop #$count"
                setTextColor(Color.parseColor("#B3FFFFFF"))
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
        frame.addView(
            center,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        frame.addView(
            TextView(app).apply {
                text = "tap to dismiss"
                setTextColor(Color.parseColor("#80FFFFFF"))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, (48 * d).toInt())
            },
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        // Ignore taps for a moment so the impact itself doesn't dismiss it.
        frame.setOnClickListener {
            if (SystemClock.elapsedRealtime() - shownAt > 1200) hide(app)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        shownAt = SystemClock.elapsedRealtime()
        wm.addView(frame, lp)
        view = frame

        if (vibrateOn(app)) buzz(app)
        if (speakOn(app)) speak(app, message(app))

        val autoMs = AUTO_MS[autoIndex(app)]
        if (autoMs > 0) {
            main.postDelayed({ if (view === frame) hide(app) }, autoMs)
        }
    }

    fun hide(ctx: Context) {
        val v = view ?: return
        val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.removeView(v)
        view = null
    }

    private fun speak(app: Context, text: String) {
        tts?.shutdown()
        var engine: TextToSpeech? = null
        engine = TextToSpeech(app) { status ->
            val e = engine
            if (e != null && status == TextToSpeech.SUCCESS) {
                // Alarm volume, so it still talks when media volume is down.
                e.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "drop")
            }
        }
        tts = engine
    }

    private fun buzz(app: Context) {
        val vib: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            app.getSystemService(Vibrator::class.java)
        }
        vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
    }
}
