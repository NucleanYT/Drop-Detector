package com.broski.dropdetector

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/** Full-screen black window drawn on top of every app. */
object DropOverlay {

    const val DEFAULT_MESSAGE = "dont drop me again broski"
    private const val PREFS = "drop"
    private const val KEY_MESSAGE = "message"

    private var view: View? = null
    private var shownAt = 0L

    // Sensitivity: slider steps 0..10 map to a free-fall threshold of 0.15..0.65 g.
    // Higher threshold = triggers more easily. Default step 4 = 0.35 g.
    const val SENS_STEPS = 10
    private const val KEY_SENS = "sensitivity"
    private const val DEFAULT_SENS = 4

    @Volatile var thresholdG = 0.35f
        private set

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun message(ctx: Context): String {
        val saved = prefs(ctx).getString(KEY_MESSAGE, null)
        return if (saved.isNullOrBlank()) DEFAULT_MESSAGE else saved
    }

    fun saveMessage(ctx: Context, text: String) {
        prefs(ctx).edit().putString(KEY_MESSAGE, text).apply()
    }

    fun sensitivity(ctx: Context): Int =
        prefs(ctx).getInt(KEY_SENS, DEFAULT_SENS).coerceIn(0, SENS_STEPS)

    fun saveSensitivity(ctx: Context, step: Int) {
        prefs(ctx).edit().putInt(KEY_SENS, step).apply()
        thresholdG = toG(step)
    }

    fun loadThreshold(ctx: Context) {
        thresholdG = toG(sensitivity(ctx))
    }

    private fun toG(step: Int) = 0.15f + 0.05f * step.coerceIn(0, SENS_STEPS)

    fun show(ctx: Context) {
        val app = ctx.applicationContext
        if (view != null || !Settings.canDrawOverlays(app)) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = app.resources.displayMetrics.density

        val frame = FrameLayout(app).apply { setBackgroundColor(Color.BLACK) }

        frame.addView(
            TextView(app).apply {
                text = message(app)
                setTextColor(Color.WHITE)
                textSize = 44f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                val p = (32 * d).toInt()
                setPadding(p, p, p, p)
            },
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        frame.addView(
            TextView(app).apply {
                text = "tap to dismiss"
                setTextColor(Color.parseColor("#555555"))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, (48 * d).toInt())
            },
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )

        // Ignore taps for a moment so the impact itself doesn't dismiss it.
        frame.setOnClickListener {
            if (SystemClock.elapsedRealtime() - shownAt > 1200) hide(app)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        shownAt = SystemClock.elapsedRealtime()
        wm.addView(frame, lp)
        view = frame
        buzz(app)
    }

    fun hide(ctx: Context) {
        val v = view ?: return
        val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.removeView(v)
        view = null
    }

    private fun buzz(app: Context) {
        val vib: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            app.getSystemService(Vibrator::class.java)
        }
        vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 100, 200), -1))
    }
}
